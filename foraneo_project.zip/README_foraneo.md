# Foráneo

**Foráneo** es una aplicación multiplataforma (móvil y web) que centraliza en un solo lugar los servicios turísticos de Nicaragua.  Permite planificar viajes, reservar hospedajes, contratar transporte, encontrar experiencias culturales y gastronómicas, y pagar de manera segura.  El objetivo es **simplificar el turismo interno** conectando a viajeros con pequeños negocios locales.

## Funcionalidades principales

- **Exploración de destinos:** búsqueda por ciudad, categoría o actividad.  Cada destino incluye fotos, descripciones y opiniones.
- **Reservas integradas:** reserva de hospedajes, tours y transporte desde la misma aplicación con confirmación en tiempo real.
- **Itinerarios personalizados:** creación de rutas y agendas según preferencias (p. ej. fin de semana en Somoto).
- **Sistema de reseñas y recompensas:** los usuarios pueden calificar experiencias y ganar puntos.
- **Seguridad y soporte:** contactos de emergencia, mapas offline y chat con proveedores.

## Tecnología

La app está desarrollada con **Flutter**, un framework de Google que permite crear aplicaciones móviles y web desde una sola base de código【169749691836257†L44-L63】.  Flutter utiliza el lenguaje Dart y proporciona las siguientes ventajas:

- Compila a código nativo en Android, iOS, web y escritorio.
- Ofrece **hot reload** para ver cambios de inmediato sin recompilar【169749691836257†L56-L58】.
- Incluye widgets basados en Material Design y su propio motor de renderizado【169749691836257†L59-L64】.
- Posee una comunidad amplia y en crecimiento【169749691836257†L66-L68】.

### Estructura del proyecto

```
foraneo/
├── lib/                  # Código Dart de la aplicación Flutter
│   ├── main.dart         # Punto de entrada
│   ├── screens/          # Pantallas (Home, Búsqueda, Detalle, Reservas, Perfil)
│   ├── widgets/          # Componentes reutilizables
│   └── services/         # Cliente REST para consumir la API backend
├── assets/               # Imágenes, fuentes y otros recursos estáticos
├── README_foraneo.md     # Este documento
└── backend/              # Proyecto backend (Node.js + Express)
    ├── app.js
    ├── routes/
    ├── models/
    └── ...
```

## Requisitos

- **Flutter** 3.13 o superior.
- **Node.js** 16+ y **npm** para el backend.
- **Base de datos** (p. ej. PostgreSQL o MySQL).
- **Git** para control de versiones.

## Instalación

1. Clona el repositorio:

   ```bash
   git clone https://github.com/tu-usuario/foraneo.git
   cd foraneo
   ```

2. Instala las dependencias de Flutter:

   ```bash
   flutter pub get
   ```

3. Configura el entorno web (opcional):

   ```bash
   flutter config --enable-web
   ```

4. Configura el backend:

   ```bash
   cd backend
   npm install
   cp .env.example .env  # configura variables como DB_HOST, DB_USER, DB_PASS
   npm start
   ```

5. Corre la aplicación móvil:

   ```bash
   flutter run
   ```

6. Corre la aplicación web:

   ```bash
   flutter run -d chrome
   ```

## Uso

- En la pantalla de **Inicio** se muestran destinos destacados y categorías.
- En **Explorar** puedes filtrar por ciudad o tipo de experiencia.
- En **Detalle** ves información completa del servicio y puedes reservar.
- La sección **Reservas** muestra tus reservas vigentes y su estado.
- En **Perfil** se gestiona la cuenta, las reseñas y el programa de recompensas.

## Contribución

Se utiliza Git y GitHub como control de versiones.  Todas las contribuciones deben realizarse mediante *pull requests* en ramas nuevas.  Procura seguir la convención de commits y documentar los cambios de manera clara.

## Licencia

Este proyecto se publica bajo la licencia MIT.
