const express = require('express');
const app = express();
const cors = require('cors');
app.use(cors());
app.use(express.json());

// Simulated in-memory data
const servicios = [
  { id: 1, nombre: 'Hostal El Río', categoria: 'Hospedaje', descripcion: 'Habitación privada con baño', precio: 25 },
  { id: 2, nombre: 'Tour Volcano', categoria: 'Experiencia', descripcion: 'Excursión guiada al volcán Masaya', precio: 40 },
];
const reservas = [];

// GET lista de servicios
app.get('/api/servicios', (req, res) => {
  res.json(servicios);
});

// POST nueva reserva
app.post('/api/reservas', (req, res) => {
  const { idServicio, idUsuario, fechaInicio, fechaFin, cantidad } = req.body;
  const servicio = servicios.find(s => s.id === idServicio);
  if (!servicio) {
    return res.status(404).json({ error: 'Servicio no encontrado' });
  }
  const reserva = {
    id: reservas.length + 1,
    idUsuario,
    servicio: servicio.nombre,
    fechaInicio,
    fechaFin,
    cantidad,
    total: cantidad * servicio.precio,
    estado: 'confirmada'
  };
  reservas.push(reserva);
  res.status(201).json(reserva);
});

// GET lista de reservas
app.get('/api/reservas', (req, res) => {
  res.json(reservas);
});

// Iniciar servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor backend corriendo en puerto ${PORT}`);
});
