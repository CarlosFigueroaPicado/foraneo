import 'package:flutter/material.dart';

void main() {
  runApp(ForaneoApp());
}

class ForaneoApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Foráneo',
      theme: ThemeData(primarySwatch: Colors.teal),
      initialRoute: '/',
      routes: {
        '/': (context) => HomeScreen(),
        '/explore': (context) => ExploreScreen(),
        '/detail': (context) => DetailScreen(),
        '/reservations': (context) => ReservationsScreen(),
        '/profile': (context) => ProfileScreen(),
      },
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Foráneo - Inicio')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Bienvenido a Foráneo', style: TextStyle(fontSize: 22)),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.pushNamed(context, '/explore'),
              child: Text('Explorar destinos'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pushNamed(context, '/reservations'),
              child: Text('Mis Reservas'),
            ),
          ],
        ),
      ),
    );
  }
}

class ExploreScreen extends StatefulWidget {
  @override
  _ExploreScreenState createState() => _ExploreScreenState();
}

class _ExploreScreenState extends State<ExploreScreen> {
  List services = [];

  @override
  void initState() {
    super.initState();
    fetchServices();
  }

  void fetchServices() async {
    // Este ejemplo usa fetch de jsonplaceholder (proxy del backend)
    final response = await Uri.parse('http://localhost:3000/api/servicios');
    // Nota: En una implementación real se usa http package y async/await
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Explorar servicios')),
      body: ListView.builder(
        itemCount: services.length,
        itemBuilder: (context, index) {
          final service = services[index];
          return ListTile(
            title: Text(service['nombre']),
            subtitle: Text(service['descripcion']),
            onTap: () {
              Navigator.pushNamed(context, '/detail', arguments: service);
            },
          );
        },
      ),
    );
  }
}

class DetailScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final dynamic service = ModalRoute.of(context)!.settings.arguments;
    return Scaffold(
      appBar: AppBar(title: Text(service != null ? service['nombre'] : 'Detalle')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(service != null ? service['descripcion'] : 'Sin información'),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Navega a reservas y pasa servicio
                Navigator.pushNamed(context, '/reservations', arguments: service);
              },
              child: Text('Reservar'),
            ),
          ],
        ),
      ),
    );
  }
}

class ReservationsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Mis Reservas')),
      body: Center(child: Text('Aquí aparecerán tus reservas')), // Implementar lista
    );
  }
}

class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Mi perfil')),
      body: Center(child: Text('Información del usuario y configuración')), // Detalles
    );
  }
}
